<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Tileset" tilewidth="32" tileheight="32" tilecount="168" columns="21">
 <image source="Tileset.png" width="672" height="256"/>
</tileset>
